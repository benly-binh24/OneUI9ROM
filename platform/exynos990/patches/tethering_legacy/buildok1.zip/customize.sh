SKIPUNZIP=1

CAPEX="$WORK_DIR/system/system/apex/com.google.android.tethering_compressed.apex"
PATCH_TMP="$TMP_DIR/tethering_legacy"
DECODED="$PATCH_TMP/decoded"
PAYLOAD="$DECODED/unknown/apex_payload"

if [ ! -f "$CAPEX" ]; then
    LOGE "Tethering CAPEX not found: ${CAPEX//$WORK_DIR/}"
    return 1
fi

if ! sudo -n true &> /dev/null; then
    LOG "\033[0;33m! Root permissions are required to unpack the Tethering APEX\033[0m"
    if ! sudo -v 2> /dev/null; then
        LOGE "Root permissions are required to unpack the Tethering APEX"
        return 1
    fi
fi

# A terminated build may leave the read-only payload mounted below PATCH_TMP.
# Unmount it before removing the previous temporary tree.
if mountpoint -q "$PATCH_TMP/mnt"; then
    LOGW "Unmounting stale Tethering APEX payload from a previous build"
    if ! sudo umount "$PATCH_TMP/mnt"; then
        LOGE "Failed to unmount stale Tethering APEX payload: ${PATCH_TMP//$SRC_DIR/}/mnt"
        return 1
    fi
fi

rm -rf "$PATCH_TMP"
mkdir -p "$PATCH_TMP"

LOG "- Extracting original Tethering APEX"
if unzip -l "$CAPEX" original_apex 2> /dev/null | grep -q "original_apex"; then
    unzip -p "$CAPEX" original_apex > "$PATCH_TMP/original.apex"
else
    # Incremental builds already contain the uncompressed APEX produced by this
    # module, even though the work-dir filename retains the _compressed suffix.
    cp -a "$CAPEX" "$PATCH_TMP/original.apex"
fi
if [ ! -s "$PATCH_TMP/original.apex" ]; then
    LOGE "Failed to extract original_apex from ${CAPEX//$WORK_DIR/}"
    return 1
fi

LOG "- Decoding original Tethering APEX"
EVAL "apktool d -j \"$(nproc)\" -o \"$DECODED\" -r \"$PATCH_TMP/original.apex\""

LOG "- Extracting apex_payload.img"
mkdir -p "$PAYLOAD" "$PATCH_TMP/mnt"
if ! sudo mount -o ro "$DECODED/unknown/apex_payload.img" "$PATCH_TMP/mnt"; then
    LOGE "Failed to mount Tethering APEX payload"
    return 1
fi
if ! sudo cp -a -T "$PATCH_TMP/mnt" "$PAYLOAD"; then
    LOGE "Failed to copy Tethering APEX payload"
    sudo umount "$PATCH_TMP/mnt" || true
    return 1
fi
if ! sudo chown -hR "$(whoami):$(whoami)" "$PAYLOAD"; then
    LOGE "Failed to change ownership of the extracted Tethering APEX payload"
    sudo umount "$PATCH_TMP/mnt" || true
    return 1
fi
rm -rf "$PAYLOAD/lost+found"

LOG "- Recording Tethering APEX filesystem metadata"
if ! sudo find "$PATCH_TMP/mnt" \
        -exec stat -c "%n %u %g %a capabilities=0x0" "{}" \; \
        > "$PATCH_TMP/fs_config"; then
    LOGE "Failed to record Tethering APEX fs_config metadata"
    sudo umount "$PATCH_TMP/mnt" || true
    return 1
fi
if ! sudo find "$PATCH_TMP/mnt" -exec sh -c '
        for path do
            label="$(getfattr -n security.selinux --only-values -h --absolute-names "$path")" || exit 1
            printf "%s %s\n" "$path" "$label"
        done
    ' sh "{}" + > "$PATCH_TMP/file_contexts"; then
    LOGE "Failed to record Tethering APEX SELinux contexts"
    sudo umount "$PATCH_TMP/mnt" || true
    return 1
fi
if ! sudo umount "$PATCH_TMP/mnt"; then
    LOGE "Failed to unmount Tethering APEX payload"
    return 1
fi
rm -rf "$PATCH_TMP/mnt" "$DECODED/unknown/apex_payload.img"

sort -o "$PATCH_TMP/file_contexts" "$PATCH_TMP/file_contexts"
sort -o "$PATCH_TMP/fs_config" "$PATCH_TMP/fs_config"
sed -i -e "s|$PATCH_TMP/mnt |/ |g" -e "s|$PATCH_TMP/mnt||g" "$PATCH_TMP/file_contexts"
sed -i -e 's|\.|\\.|g' -e 's|+|\\+|g' -e 's|\[|\\[|g' \
    -e 's|\]|\\]|g' -e 's|\*|\\*|g' "$PATCH_TMP/file_contexts"
sed -i -e "s|$PATCH_TMP/mnt | |g" -e "s|$PATCH_TMP/mnt/||g" "$PATCH_TMP/fs_config"

NETBPFLOAD="$PAYLOAD/bin/netbpfload"
PREPATCHED_NETBPFLOAD="/home/binh/ArtisanROM/platform/exynos990/patches/tethering_legacy/netbpfload"

if [ -f "$PREPATCHED_NETBPFLOAD" ]; then
    LOG "- Copying pre-patched netbpfload binary"
    cp -f "$PREPATCHED_NETBPFLOAD" "$NETBPFLOAD"
    chmod +x "$NETBPFLOAD"
else
    LOGE "Pre-patched netbpfload not found at: $PREPATCHED_NETBPFLOAD"
    return 1
fi

# Tự động gán mã băm sau khi ghi đè để vượt qua bước xác thực tiếp theo
FINAL_SHA256="$(sha256sum "$NETBPFLOAD" | cut -d ' ' -f 1)"

if [ "$(sha256sum "$NETBPFLOAD" | cut -d ' ' -f 1)" != "$FINAL_SHA256" ]; then
    LOGE "netbpfload patch validation failed"
    return 1
fi

LOG "- Rebuilding apex_payload.img"
"$SRC_DIR/scripts/build_fs_image.sh" "ext4" --no-avb \
    -o "$DECODED/unknown/apex_payload.img" -p "system" \
    "$PAYLOAD" "$PATCH_TMP/file_contexts" "$PATCH_TMP/fs_config" > /dev/null

rm -rf "$PAYLOAD" "$PATCH_TMP/file_contexts" "$PATCH_TMP/fs_config"

LOG "- Signing Tethering APEX payload"
SALT="$(sha256sum "$DECODED/unknown/apex_manifest.pb" | cut -d ' ' -f 1)"
EVAL "avbtool add_hashtree_footer --do_not_generate_fec --algorithm \"SHA256_RSA4096\" --hash_algorithm \"sha256\" --key \"$SRC_DIR/security/avb/testkey_rsa4096.pem\" --prop \"apex.key:com.android.tethering\" --salt \"$SALT\" --image \"$DECODED/unknown/apex_payload.img\""
EVAL "avbtool extract_public_key --key \"$SRC_DIR/security/avb/testkey_rsa4096.pem\" --output \"$DECODED/unknown/apex_pubkey\""

LOG "- Rebuilding uncompressed Tethering APEX"
mkdir -p "$DECODED/build/apk"
cp -a "$DECODED/original/META-INF" "$DECODED/build/apk/META-INF"
EVAL "apktool b -j \"$(nproc)\" \"$DECODED\""

BUILT_APEX="$DECODED/dist/original.apex"
if [ ! -f "$BUILT_APEX" ]; then
    LOGE "Rebuilt Tethering APEX not found"
    return 1
fi

CERT_PREFIX="aosp"
if $ROM_IS_OFFICIAL; then
    CERT_PREFIX="artisanrom"
fi

LOG "- Signing Tethering APEX container"
EVAL "signapk -a 4096 --align-file-size \"$SRC_DIR/security/${CERT_PREFIX}_platform.x509.pem\" \"$SRC_DIR/security/${CERT_PREFIX}_platform.pk8\" \"$BUILT_APEX\" \"$BUILT_APEX.signed\""

# APEXd accepts an uncompressed APEX in place of its CAPEX. Keeping the original
# path also avoids stale filesystem metadata entries during incremental builds.
mv -f "$BUILT_APEX.signed" "$CAPEX"
rm -rf "$PATCH_TMP"

unset CAPEX PATCH_TMP DECODED PAYLOAD NETBPFLOAD EXPECTED_SHA256 PATCHED_SHA256 \
    EXPECTED_85_SHA256 BROKEN_PATCHED_85_SHA256 \
    Q2_ONLY_PATCHED_85_SHA256 PATCHED_85_SHA256 \
    EXPECTED_85Q4_SHA256 PATCHED_85Q4_SHA256 ACTUAL_SHA256 FINAL_SHA256 \
    NETD_UPDATABLE EXPECTED_NETD_SHA256 PATCHED_NETD_SHA256 \
    EXPECTED_NETD_85_SHA256 BROKEN_PATCHED_NETD_85_SHA256 \
    PATCHED_NETD_85_SHA256 EXPECTED_NETD_85Q4_SHA256 PATCHED_NETD_85Q4_SHA256 \
    ACTUAL_NETD_SHA256 FINAL_NETD_SHA256 SALT \
    BUILT_APEX CERT_PREFIX
