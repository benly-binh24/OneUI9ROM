SKIPUNZIP=1

CAPEX="$WORK_DIR/system/system/apex/com.google.android.tethering_compressed.apex"
PATCH_TMP="$TMP_DIR/tethering_legacy"
DECODED="$PATCH_TMP/decoded"
PAYLOAD="$DECODED/unknown/apex_payload"

if [ ! -f "$CAPEX" ]; then
    LOGE "Tethering CAPEX not found: ${CAPEX//$WORK_DIR/}"
    return 1
fi

if ! sudo -n true &> /dev/null; then
    LOG "\033[0;33m! Root permissions are required to unpack the Tethering APEX\033[0m"
    if ! sudo -v 2> /dev/null; then
        LOGE "Root permissions are required to unpack the Tethering APEX"
        return 1
    fi
fi

# A terminated build may leave the read-only payload mounted below PATCH_TMP.
# Unmount it before removing the previous temporary tree.
if mountpoint -q "$PATCH_TMP/mnt"; then
    LOGW "Unmounting stale Tethering APEX payload from a previous build"
    if ! sudo umount "$PATCH_TMP/mnt"; then
        LOGE "Failed to unmount stale Tethering APEX payload: ${PATCH_TMP//$SRC_DIR/}/mnt"
        return 1
    fi
fi

rm -rf "$PATCH_TMP"
mkdir -p "$PATCH_TMP"

LOG "- Extracting original Tethering APEX"
if unzip -l "$CAPEX" original_apex 2> /dev/null | grep -q "original_apex"; then
    unzip -p "$CAPEX" original_apex > "$PATCH_TMP/original.apex"
else
    # Incremental builds already contain the uncompressed APEX produced by this
    # module, even though the work-dir filename retains the _compressed suffix.
    cp -a "$CAPEX" "$PATCH_TMP/original.apex"
fi
if [ ! -s "$PATCH_TMP/original.apex" ]; then
    LOGE "Failed to extract original_apex from ${CAPEX//$WORK_DIR/}"
    return 1
fi

LOG "- Decoding original Tethering APEX"
EVAL "apktool d -j \"$(nproc)\" -o \"$DECODED\" -r \"$PATCH_TMP/original.apex\""

LOG "- Extracting apex_payload.img"
mkdir -p "$PAYLOAD" "$PATCH_TMP/mnt"
if ! sudo mount -o ro "$DECODED/unknown/apex_payload.img" "$PATCH_TMP/mnt"; then
    LOGE "Failed to mount Tethering APEX payload"
    return 1
fi
if ! sudo cp -a -T "$PATCH_TMP/mnt" "$PAYLOAD"; then
    LOGE "Failed to copy Tethering APEX payload"
    sudo umount "$PATCH_TMP/mnt" || true
    return 1
fi
if ! sudo chown -hR "$(whoami):$(whoami)" "$PAYLOAD"; then
    LOGE "Failed to change ownership of the extracted Tethering APEX payload"
    sudo umount "$PATCH_TMP/mnt" || true
    return 1
fi
rm -rf "$PAYLOAD/lost+found"

LOG "- Recording Tethering APEX filesystem metadata"
if ! sudo find "$PATCH_TMP/mnt" \
        -exec stat -c "%n %u %g %a capabilities=0x0" "{}" \; \
        > "$PATCH_TMP/fs_config"; then
    LOGE "Failed to record Tethering APEX fs_config metadata"
    sudo umount "$PATCH_TMP/mnt" || true
    return 1
fi
if ! sudo find "$PATCH_TMP/mnt" -exec sh -c '
        for path do
            label="$(getfattr -n security.selinux --only-values -h --absolute-names "$path")" || exit 1
            printf "%s %s\n" "$path" "$label"
        done
    ' sh "{}" + > "$PATCH_TMP/file_contexts"; then
    LOGE "Failed to record Tethering APEX SELinux contexts"
    sudo umount "$PATCH_TMP/mnt" || true
    return 1
fi
if ! sudo umount "$PATCH_TMP/mnt"; then
    LOGE "Failed to unmount Tethering APEX payload"
    return 1
fi
rm -rf "$PATCH_TMP/mnt" "$DECODED/unknown/apex_payload.img"

sort -o "$PATCH_TMP/file_contexts" "$PATCH_TMP/file_contexts"
sort -o "$PATCH_TMP/fs_config" "$PATCH_TMP/fs_config"
sed -i -e "s|$PATCH_TMP/mnt |/ |g" -e "s|$PATCH_TMP/mnt||g" "$PATCH_TMP/file_contexts"
sed -i -e 's|\.|\\.|g' -e 's|+|\\+|g' -e 's|\[|\\[|g' \
    -e 's|\]|\\]|g' -e 's|\*|\\*|g' "$PATCH_TMP/file_contexts"
sed -i -e "s|$PATCH_TMP/mnt | |g" -e "s|$PATCH_TMP/mnt/||g" "$PATCH_TMP/fs_config"

NETBPFLOAD="$PAYLOAD/bin/netbpfload"
EXPECTED_SHA256="cad99f3ef16dfb940e2a29b0a5061d0c8d21063604ace33877023bc78a27ad13"
PATCHED_SHA256="b4458f3107e66cff08e01de87586d2659578a4f16f09b13f846f047920eb0e61"
EXPECTED_85_SHA256="7b77a7ac01d01b6787544f2a01a77f4fd929ec6da0625c6f413764e8622ff2a2"
BROKEN_PATCHED_85_SHA256="d7b634fad672b400656f2dced2504b25090e54992d189133b3eaf1dab7c54813"
Q2_ONLY_PATCHED_85_SHA256="8ee75c6fc3eaf73cd6d93cfd9d96b253e4297706921bd57bedf224a5df16468a"
PATCHED_85_SHA256="13e9fedd343f603445b7094aa6d44266614bbd7e1962c10f56b87f445b219ad0"
EXPECTED_85Q4_SHA256="775d705134ac47146a536d31e76af3d439d0e29d48087bc6c64d04c102c4bed6"
PATCHED_85Q4_SHA256="3a768b190792a44bd3bf5ac6b47b2c7cfa6ca491f0d49726f7d284492379bdfe"
ACTUAL_SHA256="$(sha256sum "$NETBPFLOAD" | cut -d ' ' -f 1)"

if [ "$ACTUAL_SHA256" = "$EXPECTED_SHA256" ]; then
    # NetBpfLoad v0.47 aborts API 36 on kernels older than 5.4. Exynos 990 uses
    # Linux 4.19 with the required BPF functionality backported, so skip only
    # this hard version gate while preserving the real kernel version for BPF
    # program selection.
    #
    # Before: tbnz w0, #0, <Android 25Q2 requires kernel 5.4 error path>
    # After:  nop
    LOG "- Disabling NetBpfLoad Android 25Q2 kernel 5.4 version gate"
    HEX_PATCH "$NETBPFLOAD" \
        "1c070094c0160036680800f0" \
        "1c0700941f2003d5680800f0" > /dev/null
    FINAL_SHA256="$PATCHED_SHA256"
elif [ "$ACTUAL_SHA256" = "$PATCHED_SHA256" ]; then
    LOG "- NetBpfLoad Android 25Q2 kernel gate is already disabled"
    FINAL_SHA256="$PATCHED_SHA256"
elif [ "$ACTUAL_NETD_SHA256" = "b201bb4871e76bf68f096892e1358efb51dac1008f42d3b3d4d7637a284817f9" ]; then
    # Áp dụng bản vá tương tự cho build libnetd_updatable mới phát hiện
    LOG "- Disabling netd new build kernel version gate"
    HEX_PATCH "$NETD_UPDATABLE" \
        "48d341398805003600088052" \
        "48d341392c00001400088052" > /dev/null
    FINAL_NETD_SHA256="0708880c6593ed49915c8608438719fd34eddbf44a67157ff6082ab669f5df64"
elif [ "$ACTUAL_SHA256" = "$BROKEN_PATCHED_85_SHA256" ]; then
    LOG "- Repairing cached NetBpfLoad One UI 8.5 kernel gate patch"
    HEX_PATCH "$NETBPFLOAD" \
        "5f01057168010054ea5244391f2003d5a1fffff0" \
        "5f01057168010054ea52443909000014a1fffff0" > /dev/null
    HEX_PATCH "$NETBPFLOAD" \
        "1f110a71280200546808009008614439c8010036a1fffff0" \
        "1f110a712802005468080090086144390e000014a1fffff0" > /dev/null
    FINAL_SHA256="$PATCHED_85_SHA256"
elif [ "$ACTUAL_SHA256" = "$Q2_ONLY_PATCHED_85_SHA256" ]; then
    LOG "- Disabling cached NetBpfLoad One UI 8.5 kernel 5.10 gate"
    HEX_PATCH "$NETBPFLOAD" \
        "1f110a71280200546808009008614439c8010036a1fffff0" \
        "1f110a712802005468080090086144390e000014a1fffff0" > /dev/null
    FINAL_SHA256="$PATCHED_85_SHA256"
elif [ "$ACTUAL_SHA256" = "$PATCHED_85_SHA256" ]; then
    LOG "- NetBpfLoad One UI 8.5 kernel gate is already disabled"
    FINAL_SHA256="$PATCHED_85_SHA256"
elif [ "$ACTUAL_SHA256" = "$EXPECTED_85Q4_SHA256" ]; then
    # Kernel gates in NetBpfLoad::main(): every check is "kernel (>>16) <= X and
    # compat flag" -> log error + return rc 3..7. Each conditional b.hi / b.ls that
    # guards an error block is turned into an unconditional jump over it (or a nop
    # for the 4.9 check, which falls through), so legacy kernels (<= 4.19) boot
    # while the real kernel version is still used for BPF program selection.
    #
    # 0xa394: b.ls -> nop        (S & T require 4.9,  rc 3)
    # 0xa3a4: b.hi -> b          (T requires 4.14,    rc 4)
    # 0xa534: b.hi -> b          (V requires 4.19,    rc 5)
    # 0xa568: b.hi -> b          (25Q2 requires 5.4,  rc 6)
    # 0xa598: b.hi -> b          (25Q4 requires 5.10, rc 7)
    # 0xa5c0: b.hi -> b          (26Q3 requires 5.15, rc 7)
    LOG "- Disabling NetBpfLoad Android 16 QPR2 kernel 4.9/4.14/4.19/5.4/5.10/5.15 version gates"
    HEX_PATCH "$NETBPFLOAD" \
        "1f211071290a0054ca7e1153" \
        "1f2110711f2003d5ca7e1153" > /dev/null
    HEX_PATCH "$NETBPFLOAD" \
        "5f190871280c005409634439" \
        "5f1908716100001409634439" > /dev/null
    HEX_PATCH "$NETBPFLOAD" \
        "297144394801005429010034" \
        "297144390a00001429010034" > /dev/null
    HEX_PATCH "$NETBPFLOAD" \
        "7f010571680100546b824439" \
        "7f0105710b0000146b824439" > /dev/null
    HEX_PATCH "$NETBPFLOAD" \
        "5f110a71280100546a0800d0" \
        "5f110a71090000146a0800d0" > /dev/null
    HEX_PATCH "$NETBPFLOAD" \
        "1f39147188010054680800d0" \
        "1f3914710c000014680800d0" > /dev/null
    FINAL_SHA256="$PATCHED_85Q4_SHA256"
else
    LOGE "Unsupported netbpfload build: $ACTUAL_SHA256"
    LOGE "Expected a supported One UI 8.0/8.5 original or patched build"
    return 1
fi

if [ "$(sha256sum "$NETBPFLOAD" | cut -d ' ' -f 1)" != "$FINAL_SHA256" ]; then
    LOGE "netbpfload patch validation failed"
    return 1
fi

NETD_UPDATABLE="$PAYLOAD/lib64/libnetd_updatable.so"
EXPECTED_NETD_SHA256="eda006b2bc421bb2581b2193c10444b7ee158bf728034e1e57ba8425e82a6386"
PATCHED_NETD_SHA256="3ebd27e5f3a6f6c4efe04672c6b835701c8cf6cec584792e907e75d140bee67f"
EXPECTED_NETD_85_SHA256="b15352158c8633d3a3b743331ce149daa29c6b7d656eed014392da082cf187cc"
BROKEN_PATCHED_NETD_85_SHA256="4a6ba0362a869ee8e91b8317b57614cbd9d77872416543c413262e4c52b10aa2"
PATCHED_NETD_85_SHA256="d62c8a9d351296e992f965e396c52cddc0db435ebd89b02d3c6834ade7b0c0d3"
EXPECTED_NETD_85Q4_SHA256="5a23d23324abd7fc9a606e5a0e234b20313d0c003a4d117c17a64d71e8b47743"
PATCHED_NETD_85Q4_SHA256="0708880c6593ed49915c8608438719fd34eddbf44a67157ff6082ab669f5df64"
ACTUAL_NETD_SHA256="$(sha256sum "$NETD_UPDATABLE" | cut -d ' ' -f 1)"

if [ "$ACTUAL_NETD_SHA256" = "$EXPECTED_NETD_SHA256" ]; then
    # libnetd_updatable performs the same API 36/kernel 5.4 check when netd
    # starts. Keeping this gate makes netd abort after NetBpfLoad successfully
    # loaded the kernel-4.19 variants of its maps and programs.
    #
    # Before: b.ls <25Q2+ kernel version unsupported error path>
    # After:  nop
    LOG "- Disabling netd Android 25Q2 kernel 5.4 version gate"
    HEX_PATCH "$NETD_UPDATABLE" \
        "1f01096be9430054e00301aa" \
        "1f01096b1f2003d5e00301aa" > /dev/null
    FINAL_NETD_SHA256="$PATCHED_NETD_SHA256"
elif [ "$ACTUAL_NETD_SHA256" = "$PATCHED_NETD_SHA256" ]; then
    LOG "- netd Android 25Q2 kernel gate is already disabled"
    FINAL_NETD_SHA256="$PATCHED_NETD_SHA256"
elif [ "$ACTUAL_NETD_SHA256" = "$EXPECTED_NETD_85_SHA256" ]; then
    # Like NetBpfLoad above, this TBZ skips the unsupported-kernel error
    # object. Replacing it with NOP would fall through into the error; branch
    # unconditionally to the normal continuation instead.
    LOG "- Disabling netd One UI 8.5 kernel 5.4 version gate"
    HEX_PATCH "$NETD_UPDATABLE" \
        "1f010571c805005448a341398805003600088052" \
        "1f010571c805005448a341392c00001400088052" > /dev/null
    FINAL_NETD_SHA256="$PATCHED_NETD_85_SHA256"
elif [ "$ACTUAL_NETD_SHA256" = "$BROKEN_PATCHED_NETD_85_SHA256" ]; then
    LOG "- Repairing cached netd One UI 8.5 kernel gate patch"
    HEX_PATCH "$NETD_UPDATABLE" \
        "1f010571c805005448a341391f2003d500088052" \
        "1f010571c805005448a341392c00001400088052" > /dev/null
    FINAL_NETD_SHA256="$PATCHED_NETD_85_SHA256"
elif [ "$ACTUAL_NETD_SHA256" = "$PATCHED_NETD_85_SHA256" ]; then
    LOG "- netd One UI 8.5 kernel gate is already disabled"
    FINAL_NETD_SHA256="$PATCHED_NETD_85_SHA256"
elif [ "$ACTUAL_NETD_SHA256" = "$EXPECTED_NETD_85Q4_SHA256" ]; then
    # Same TBZ -> B rewrite as the One UI 8.5 gate above, on the Android 16
    # QPR2 libnetd_updatable build.
    LOG "- Disabling netd Android 16 QPR2 kernel 5.4 version gate"
    HEX_PATCH "$NETD_UPDATABLE" \
        "48d341398805003600088052" \
        "48d341392c00001400088052" > /dev/null
    FINAL_NETD_SHA256="$PATCHED_NETD_85Q4_SHA256"
else
    LOGE "Unsupported libnetd_updatable build: $ACTUAL_NETD_SHA256"
    LOGE "Expected a supported One UI 8.0/8.5 original or patched build"
    return 1
fi

if [ "$(sha256sum "$NETD_UPDATABLE" | cut -d ' ' -f 1)" != "$FINAL_NETD_SHA256" ]; then
    LOGE "libnetd_updatable patch validation failed"
    return 1
fi

LOG "- Rebuilding apex_payload.img"
"$SRC_DIR/scripts/build_fs_image.sh" "ext4" --no-avb \
    -o "$DECODED/unknown/apex_payload.img" -p "system" \
    "$PAYLOAD" "$PATCH_TMP/file_contexts" "$PATCH_TMP/fs_config" > /dev/null

rm -rf "$PAYLOAD" "$PATCH_TMP/file_contexts" "$PATCH_TMP/fs_config"

LOG "- Signing Tethering APEX payload"
SALT="$(sha256sum "$DECODED/unknown/apex_manifest.pb" | cut -d ' ' -f 1)"
EVAL "avbtool add_hashtree_footer --do_not_generate_fec --algorithm \"SHA256_RSA4096\" --hash_algorithm \"sha256\" --key \"$SRC_DIR/security/avb/testkey_rsa4096.pem\" --prop \"apex.key:com.android.tethering\" --salt \"$SALT\" --image \"$DECODED/unknown/apex_payload.img\""
EVAL "avbtool extract_public_key --key \"$SRC_DIR/security/avb/testkey_rsa4096.pem\" --output \"$DECODED/unknown/apex_pubkey\""

LOG "- Rebuilding uncompressed Tethering APEX"
mkdir -p "$DECODED/build/apk"
cp -a "$DECODED/original/META-INF" "$DECODED/build/apk/META-INF"
EVAL "apktool b -j \"$(nproc)\" \"$DECODED\""

BUILT_APEX="$DECODED/dist/original.apex"
if [ ! -f "$BUILT_APEX" ]; then
    LOGE "Rebuilt Tethering APEX not found"
    return 1
fi

CERT_PREFIX="aosp"
if $ROM_IS_OFFICIAL; then
    CERT_PREFIX="artisanrom"
fi

LOG "- Signing Tethering APEX container"
EVAL "signapk -a 4096 --align-file-size \"$SRC_DIR/security/${CERT_PREFIX}_platform.x509.pem\" \"$SRC_DIR/security/${CERT_PREFIX}_platform.pk8\" \"$BUILT_APEX\" \"$BUILT_APEX.signed\""

# APEXd accepts an uncompressed APEX in place of its CAPEX. Keeping the original
# path also avoids stale filesystem metadata entries during incremental builds.
mv -f "$BUILT_APEX.signed" "$CAPEX"
rm -rf "$PATCH_TMP"

unset CAPEX PATCH_TMP DECODED PAYLOAD NETBPFLOAD EXPECTED_SHA256 PATCHED_SHA256 \
    EXPECTED_85_SHA256 BROKEN_PATCHED_85_SHA256 \
    Q2_ONLY_PATCHED_85_SHA256 PATCHED_85_SHA256 \
    EXPECTED_85Q4_SHA256 PATCHED_85Q4_SHA256 ACTUAL_SHA256 FINAL_SHA256 \
    NETD_UPDATABLE EXPECTED_NETD_SHA256 PATCHED_NETD_SHA256 \
    EXPECTED_NETD_85_SHA256 BROKEN_PATCHED_NETD_85_SHA256 \
    PATCHED_NETD_85_SHA256 EXPECTED_NETD_85Q4_SHA256 PATCHED_NETD_85Q4_SHA256 \
    ACTUAL_NETD_SHA256 FINAL_NETD_SHA256 SALT \
    BUILT_APEX CERT_PREFIX